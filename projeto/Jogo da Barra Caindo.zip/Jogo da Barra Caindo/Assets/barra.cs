using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class barra : MonoBehaviour
{
    public Text texto;
    public AudioSource caiu;
    public GameObject ferro;
    private Rigidbody rb;
    // Start is called before the first frame update
    void Start()
    {
        rb = ferro.GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetAxis("Vertical")<0)
        {
            rb.useGravity = true;
            texto.enabled = false;
        }
    }

    void OnCollisionEnter(Collision other)
    {
        caiu.Play();
    }
}
